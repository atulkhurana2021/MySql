package Entities;

public enum ConstraintType {

    NULL,LENGTH,UPPERCASE,VALUE
}
