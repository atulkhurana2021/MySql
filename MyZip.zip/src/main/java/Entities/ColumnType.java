package Entities;

public enum ColumnType {
    INT,VARCHAR
}
