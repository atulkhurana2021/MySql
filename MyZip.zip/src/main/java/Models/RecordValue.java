package Models;


public class RecordValue {
    private ColumnType columnType;
    private String columnName;
    private Object value;


}
