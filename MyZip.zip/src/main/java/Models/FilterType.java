package Models;

public enum FilterType {
    EQUALS
}
