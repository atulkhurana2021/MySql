package Models;

public enum ColumnType {
    INT,VARCHAR
}
