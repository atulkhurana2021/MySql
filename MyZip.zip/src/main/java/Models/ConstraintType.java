package Models;

public enum ConstraintType {

    NULL,LENGTH,UPPERCASE,VALUE
}
